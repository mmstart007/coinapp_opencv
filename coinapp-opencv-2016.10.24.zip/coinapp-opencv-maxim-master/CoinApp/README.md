# coinapp-opencv-maxim

Please download opencv2.framework from the official OpenCV site.<br/>
http://opencv.org/downloads.html<br/>
OpenCV Version: 2.4.11<br/>
Copy downloaded file to the following path.<br/>
CoinApp/ObjectiveCModules/opencv/<br/>

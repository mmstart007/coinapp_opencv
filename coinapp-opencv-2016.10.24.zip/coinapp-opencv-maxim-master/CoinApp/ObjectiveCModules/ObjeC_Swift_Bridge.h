//
//  ObjeC_Swift_Bridge.h
//  CoinApp
//
//  Created by Maxim on 10/19/16.
//  Copyright (c) 2016 Maxim. All rights reserved.
//

#ifndef CoinApp_ObjeC_Swift_Bridge_h
#define CoinApp_ObjeC_Swift_Bridge_h

#import "OpenCVWrapper.h"
#import "UIImage+Rotate.h"
#import "UIImage+Crop.h"
#import "UIImage+Scale.h"
#import "UIImage+Mask.h"

#endif
